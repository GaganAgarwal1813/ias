from flask import Flask, redirect, render_template, request 
import managedb
from flask import Flask, render_template
from flask_wtf import FlaskForm
from wtforms import FileField, SubmitField
from werkzeug.utils import secure_filename
import os
from wtforms.validators import InputRequired
# from docker.director import Director
import utils.extract_validate as extract_validate
import utils.data_helper as data_helper
import pymongo
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'
app.config['UPLOAD_FOLDER'] = 'files'

class UploadFileForm(FlaskForm):
    file = FileField("File", validators=[InputRequired()])
    submit = SubmitField("Upload File")

@app.route('/')  
def message():  
      return render_template("login.html")  
    
@app.route('/signup', methods=["GET"])  
def signup():
    return render_template("signup.html")  

@app.route('/storeinfo', methods=["POST"])  
def storeinfo():
    username= request.form['username']
    password=request.form['password']
    AI =request.form.get('AI Developer')
    Deployer=request.form.get('Deployer')
    Admin=request.form.get('Admin')
    App=request.form.get('App Developer')
    roles_list=[]
    if AI is not None:
        roles_list.append("AI")
    if Deployer is not None:
        roles_list.append("Deployer")
    if Admin is not None:
        roles_list.append("Admin")
    if App is not None:
        roles_list.append("App")
    print(roles_list)
    ret_statement=managedb.storeData(username,password,roles_list)
    if(ret_statement=="User Already Exist"):
        return render_template("signup.html")
    return render_template("login.html")  


@app.route('/login', methods=["POST"])  
def login():
    username= request.form['username']
    password=request.form['password']
    role =request.form['role']
    check=managedb.checkCredentials(username,password,role)
    if(check=="Invalid Credentials" or check=="Invalid Role"):
        return render_template("login.html")  

    # print(username)
    # print(password)
    if(role=="AI"):
        return redirect("/upload")  
    if(role=="Deployer"):
        return redirect("/deployer") 
    if(role=="Admin"):
        return render_template("admin.html")  
    if(role=="App"):
        return redirect("/upload")  


@app.route('/upload', methods=['GET',"POST"])
def upload():
    form = UploadFileForm()
    if form.validate_on_submit():
        file = form.file.data # First grab the file
        #create a custom filename
        cur_index = data_helper.get_last_index()
        filename = "model_"+str(cur_index)+".zip"
        print(os.path.join(os.path.abspath(os.path.dirname(__file__)),app.config['UPLOAD_FOLDER']))
        file.save(os.path.join(os.path.abspath(os.path.dirname(__file__)),app.config['UPLOAD_FOLDER'],filename)) # Then save the file
    
        # validation_val=extract_validate.validation()
        # if(validation_val):
        #     return "File uploaded and Authenticated successfully" 
        # return "File is not uploaded and Auth successfully"
        return render_template('Ai_Dashboard.html', form=form)

    return render_template('index.html', form=form)


@app.route('/deployer', methods=['GET',"POST"])
def deployer():
    myclient = pymongo.MongoClient("mongodb://20.228.199.180:3000/")
    mydb1 = myclient["mydatabase"]
    mycol1 = mydb1["application_service"]
    mydb2 = myclient["platformDB"]
    mycol2 = mydb2["senor_detail"]
    print("Sensoer details",mycol2)
    app_list = []
    sensor_list = []

    x = mycol1.find({},{'_id':0})
    for i in x:
        app_list.append(i)

    x = mycol2.find({},{'_id':0})
    for i in x:
        sensor_list.append(i)

    app.logger.debug(app_list)
    print("Sensorlist",sensor_list)
    # app id and sensor id
    count=[{'name':'priyansh','age':23},{'name':'shlok','age':24},{'name':'rahul','age':23}]
    files=os.listdir('files/')
    print(files)
    return render_template('deployer.html',app_list = app_list, sensor_list=sensor_list,files_list=files)



@app.route("/test" , methods=['GET', 'POST'])
def test():
    select = request.form.get('count1')
    # print(str(select))
    select1 = request.form.getlist('check')
    # print(str(select1))
    return(str(select))


@app.route("/deploylist" , methods=['GET', 'POST'])
def deploylist():
    select = request.form['model']
    print(str(select))
    # select1 = request.form.getlist('check')
    # # print(str(select1))
    # return(str(select))

@app.route('/search_query', methods=["POST"])
def searchQuery():
    operation =request.form['operation']
    if(operation=="ViewUsers"):
        userslist=managedb.View_Users()
        # print(userslist)
        my_dict={}
        for i in range(0,len(userslist)):
            my_dict[i]=userslist[i]
        print(my_dict)
        return render_template('ViewUsers.html', data=my_dict)
    else:
        uname=request.form['username']
        if(operation=="DeleteUser"):
            msg=managedb.deleteUser(uname)
            my_dict1={"msg":msg}
            return render_template('deleteUsers.html', data=my_dict1)
        elif(operation=="ViewRoles"):
            msg=managedb.viewRoles(uname)
            my_dict={}
            for i in range(0,len(msg)):
                my_dict[i]=msg[i]
            print(my_dict)
            return render_template('ViewUsers.html', data=my_dict)

if __name__ == '__main__':  
   app.run(debug = True)  